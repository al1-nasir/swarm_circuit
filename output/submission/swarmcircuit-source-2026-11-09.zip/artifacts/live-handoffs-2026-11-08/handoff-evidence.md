# Agent handoff checks

The source-data checker recomputes CSV facts outside the reporting model. It checks only the supported typed quantities and limitation labels, not arbitrary model rationale. Writer and reviewer use the same configured provider; separate roles are not independent model families.

The original draft received a separate model review and typed fact checks.

```json
{
  "independently_computed_csv_facts": {
    "first_quarter_revenue": "120000",
    "last_quarter_revenue": "166980",
    "revenue_growth_percent": "39.15",
    "customer_quarters": 1800,
    "quarters": 4
  },
  "original_draft_check_errors": [],
  "reviewer_verdict": "accept",
  "reviewer_issues": [],
  "repair_used": false,
  "final_typed_claim_errors": []
}
```
