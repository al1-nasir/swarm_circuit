# Writer's original draft

Structured model output, retained as evidence. Free-form rationale is not independently fact-checked.

```json
{
  "facts": {
    "first_quarter_revenue": "120000",
    "last_quarter_revenue": "166980",
    "revenue_growth_percent": "39.15",
    "customer_quarters": 1800,
    "quarters": 4
  },
  "limitations": [
    "revenue_is_not_profit",
    "customer_quarters_are_not_unique_customers",
    "four_quarters_do_not_establish_a_forecast"
  ],
  "rationale": "The brief reports revenue growth from $120,000 in the first quarter to $166,980 in the last quarter over four quarters, a 39.15% increase. It also notes 1,800 customer-quarters. These figures are supported by the provided facts. The limitations are included because revenue does not equal profit, customer-quarters do not represent unique customers, and four quarters of data cannot establish a forecast."
}
```
