# Quarterly dataset summary

- First-quarter revenue: 120000 sample units
- Last-quarter revenue: 166980 sample units
- Revenue growth from first to last quarter: 39.15%
- Customer-quarters observed: 1800

Customer-quarters add the four quarterly counts; they are not unique customers.

Local sample data; source calculations are deterministic; model claims are retained separately.
