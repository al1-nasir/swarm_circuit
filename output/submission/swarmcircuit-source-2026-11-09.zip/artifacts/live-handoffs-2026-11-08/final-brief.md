# Checked quarterly sales brief

## Supported result

Revenue grew 39.15% between the first and last quarters, from 120000 to 166980 sample units.

The source contains 4 quarters and 1800 customer-quarters.

## Limits

Revenue is not profit: no cost data is present. Customer-quarters sum quarterly counts and do not measure unique customers. Four quarters do not establish a forecast or seasonality.

## How this handoff was checked

A separate reviewer accepted the writer's actual structured draft. Its typed facts also passed an independent CSV check before publication.

This document renders the supported checked claims. Free-form agent rationale is retained separately as unverified evidence. The two roles use the same provider. Local synthetic data; no real company data, production tools or general safety guarantee.
