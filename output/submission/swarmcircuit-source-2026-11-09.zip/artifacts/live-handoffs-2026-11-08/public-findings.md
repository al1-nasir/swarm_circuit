# Reading the sales brief

These notes use no restricted data and can be prepared independently of dataset access.

- Revenue measures sales before expenses. Growing revenue does not establish profit.
- Quarter-over-quarter growth compares one quarter with the preceding quarter.
- Four quarterly values alone cannot establish seasonality or forecast future sales.
- Adding quarterly customer counts gives customer-quarters, not unique customers.

## Further reading

- SEC, Beginner's Guide to Financial Statements:
  https://www.sec.gov/investor/pubs/begfinstmtguide.htm
- Census Bureau, Quarterly Financial Report:
  https://www.census.gov/programs-surveys/qfr.html

Bundled explanatory notes; links were not fetched during this run.
