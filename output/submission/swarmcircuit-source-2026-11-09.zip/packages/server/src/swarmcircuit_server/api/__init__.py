"""FastAPI application surface."""
