"""SwarmCircuit local observation service."""
