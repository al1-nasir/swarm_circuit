SwarmCircuit local source and live-handoff evidence — November 9, 2026

The report was submitted through the official form on Nov 9 at 14:56 Pakistan
time; the website confirmed receipt, while email confirmation remains unchecked.
This source archive has not itself been uploaded or published. No PDF report is
included in this source-only archive. The known code destination is
https://github.com/al1-nasir/swarm_circuit, private during preparation with user
release pending. A separate submission bundle contains the reviewed PDF and
LaTeX sources. The official deadline is Nov 9 at 11:59 UTC / 16:59 Pakistan time.
See docs/SUBMISSION_PREFLIGHT_2026-11-09.md.

Contents: application/SDK source, migrations through 007, API contracts, tests,
locked dependency declarations, documentation, static UI assets and the retained
actual live writer/reviewer case in artifacts/live-handoffs-2026-11-08.
Three completed release-check logs are included as test evidence.
Dependency installations, build caches, application runtime logs, .env files, private SQLite
data/backups, supplied source DOCX files and the old preparation archive are
excluded. .env.example contains examples only. No repository license is selected;
this local bundle does not confer redistribution rights.

The actual live case completed 6/6 SDK tasks using two model roles with the same
configured provider. Two calls reported 997 input and 304 output tokens. Typed
sample facts passed independent source checks; no repair was needed in this run.
Arbitrary model rationale remains unverified. This is not a statistical benchmark,
a production safety guarantee or proof of independent model-family judgment.
The November 5 synthetic study and failed model pilots remain historical evidence
in the separate preparation bundle, not reproduced in this source archive.

To run locally after extraction:
  make bootstrap
  make init-local
  make db-init
  make server PORT=18005
  make studio-install
  SWARM_API_URL=http://127.0.0.1:18005 make studio STUDIO_PORT=3300
Open http://127.0.0.1:3300/demo. Offline mode is the default and makes no model
calls. Live mode requires private server provider settings, explicit live review
and sample-data access. It is capped at three calls; charges may apply.
The saved evidence does not populate a fresh private database automatically.

SOURCE_MANIFEST.json hashes all selected files and this README. The external
manifest also hashes SOURCE_MANIFEST.json and the completed ZIP. Verify hashes
after extraction. Nothing in this archive contains a fabricated Git commit.
