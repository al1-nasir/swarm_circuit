"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError } from "@/lib/api";
import { commandLabel, short } from "@/lib/model";
import type { Command, Snapshot } from "@/lib/types";
import { useProject } from "./shell";
import { Status } from "./ui";

type Preview = {
  approval_id: string;
  root_task_id: string;
  dependent_task_ids: string[];
  targets: {
    task_id: string;
    runtime_session_id: string;
    expected_task_version: number;
    checkpoint_id: string;
    fencing_epoch: number;
  }[];
  skipped: { task_id: string; reason: string }[];
  preview_sha256: string;
  max_targets: number;
  policy: string;
  commands: Command[];
  command_ids: string[];
  policy_request_id?: string;
};
type Pending = { key: string; approvalId: string; runId: string };
export function Containment({
  data,
  onRefresh,
}: {
  data: Snapshot;
  onRefresh: () => void;
}) {
  const { config, health } = useProject();
  const runId = data.run.run_id;
  const storage = `swarmcircuit:policy-intent:v1:${runId}`;
  const [open, setOpen] = useState(false);
  const [approval, setApproval] = useState("");
  const [reason, setReason] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [pending, setPending] = useState<Pending | null>(null);
  const [record, setRecord] = useState<Preview | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const activeKey = useRef<string | null>(null);
  activeKey.current = pending?.key || null;
  const eligible = data.approvals.items.filter((a) => a.state === "pending");
  const label = (id: string) =>
    data.taskGraph.nodes.find((n) => n.id === id)?.label || short(id);
  const live =
    Boolean(config?.operator) &&
    health === "ready" &&
    data.run.mode === "control";
  useEffect(() => {
    try {
      const p = JSON.parse(localStorage.getItem(storage) || "null");
      if (p && p.runId === runId && /^[0-9a-f-]{36}$/i.test(p.key))
        setPending(p);
    } catch {
      /* Storage is optional; backend keys remain durable. */
    }
    setRecord(null);
    setPreview(null);
    setError("");
  }, [runId, storage]);
  useEffect(() => {
    if (open && !dialog.current?.open) dialog.current?.showModal();
    else if (!open && dialog.current?.open) dialog.current.close();
  }, [open]);
  const reconcile = useCallback(async () => {
    if (!pending) return;
    try {
      const saved = await api<Preview>(
        `runs/${runId}/backpressure?key=${encodeURIComponent(pending.key)}`,
      );
      if (activeKey.current !== pending.key) return;
      setRecord(saved);
      setError("");
      onRefresh();
      return saved;
    } catch (e) {
      if (activeKey.current !== pending.key) return;
      setError(
        e instanceof ApiError && e.status === 404
          ? "No durable policy record found yet. Preserve the original request key and recheck; do not submit a replacement."
          : e instanceof Error
            ? e.message
            : "Policy history unavailable.",
      );
    }
  }, [pending, runId, onRefresh]);
  useEffect(() => {
    if (!pending) return;
    let stopped = false;
    const timer = setInterval(() => {
      void poll();
    }, 2000);
    async function poll() {
      const r = await reconcile();
      if (
        !stopped &&
        r &&
        r.commands.every((c) => !["queued", "dispatched"].includes(c.state))
      )
        clearInterval(timer);
    }
    void poll();
    return () => {
      stopped = true;
      clearInterval(timer);
    };
  }, [reconcile, pending]);
  async function review() {
    if (!live || !reason.trim() || !approval) return;
    setBusy(true);
    setError("");
    try {
      setPreview(
        await api<Preview>(`runs/${runId}/backpressure`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Idempotency-Key": crypto.randomUUID(),
          },
          body: JSON.stringify({
            approval_id: approval,
            reason: reason.trim(),
            apply: false,
          }),
        }),
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Preview unavailable");
    } finally {
      setBusy(false);
    }
  }
  async function apply() {
    if (!preview || !live || busy) return;
    const intent = { key: crypto.randomUUID(), approvalId: approval, runId };
    try {
      localStorage.setItem(storage, JSON.stringify(intent));
    } catch {
      /* Keep the key in this tab even when local storage is unavailable. */
    }
    activeKey.current = intent.key;
    setPending(intent);
    setBusy(true);
    setError("");
    try {
      const saved = await api<Preview>(`runs/${runId}/backpressure`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Idempotency-Key": intent.key,
        },
        body: JSON.stringify({
          approval_id: approval,
          reason: reason.trim(),
          apply: true,
          expected_preview_sha256: preview.preview_sha256,
        }),
      });
      setRecord(saved);
      setOpen(false);
      setPreview(null);
      onRefresh();
    } catch (e) {
      if (e instanceof ApiError && e.status >= 400 && e.status < 500) {
        activeKey.current = null;
        setPending(null);
        try {
          localStorage.removeItem(storage);
        } catch {}
        setPreview(null);
        setError(`${e.message}. Review a fresh preview before submitting.`);
      } else {
        setOpen(false);
        setError(
          "Submission outcome unknown. Reconcile the original request in policy history; no replacement request was sent.",
        );
      }
    } finally {
      setBusy(false);
    }
  }
  const uncertain = Boolean(
    pending &&
    (!record ||
      record.commands.some((c) =>
        ["queued", "dispatched", "unknown"].includes(c.state),
      )),
  );
  const affected = new Set(preview?.dependent_task_ids || []);
  const independent = data.taskGraph.nodes.filter((n) => !affected.has(n.id));
  if (!eligible.length && !pending) return null;
  return (
    <section className="panel containment-panel">
      <div className="panel-title">
        <div>
          <h2>Dependency containment</h2>
          <p className="metadata muted">
            Hold eligible SDK boundaries in one declared dependency branch.
          </p>
        </div>
        <button
          className="button secondary"
          disabled={!live || !eligible.length || uncertain}
          onClick={() => {
            setApproval(eligible[0].approval_id);
            setReason("");
            setPreview(null);
            setError("");
            setOpen(true);
          }}
        >
          Review containment
        </button>
      </div>
      {!live && (
        <p className="containment-note">
          {data.run.mode !== "control"
            ? "Control-mode SDK hosts are required. This Observe run remains read-only."
            : !config?.operator
              ? "A local operator credential is required."
              : "Reconnect to the backend before requesting control."}
        </p>
      )}
      {error && (
        <div className="banner warning" role="status">
          {error}
        </div>
      )}
      {pending && (
        <div className="policy-record">
          <div className="row-title">
            <strong>Policy request {short(pending.key)}</strong>
            <button className="button small" onClick={() => void reconcile()}>
              Recheck history
            </button>
          </div>
          <p className="metadata muted">
            Queued requests are pending. Only a matching runtime ACK confirms a
            hold. Approval remains controlled by its external authority.
          </p>
          {record ? (
            <>
              <div className="table-scroll">
                <table className="payment-table">
                  <thead>
                    <tr>
                      <th>Task</th>
                      <th>Canonical outcome</th>
                      <th>Runtime acknowledgements</th>
                    </tr>
                  </thead>
                  <tbody>
                    {record.commands.map((c) => (
                      <tr key={c.command_id}>
                        <td>{label(c.task_id)}</td>
                        <td>
                          <Status value={c.state}>{commandLabel(c)}</Status>
                        </td>
                        <td>
                          {c.acknowledgements.length} recorded · epoch{" "}
                          {c.session_fencing_epoch}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {record.skipped.length > 0 && (
                <p className="metadata muted">
                  {record.skipped.length} targets were skipped: no blanket
                  containment is claimed.
                </p>
              )}
              {!uncertain && (
                <button
                  className="text-link"
                  onClick={() => {
                    try {
                      localStorage.removeItem(storage);
                    } catch {
                      /* Storage may be unavailable; this tab can still dismiss. */
                    }
                    activeKey.current = null;
                    setPending(null);
                    setRecord(null);
                  }}
                >
                  Dismiss from this view
                </button>
              )}
            </>
          ) : (
            <p className="metadata">
              Awaiting a durable policy record. Original key:{" "}
              <span className="mono break">{pending.key}</span>
            </p>
          )}
        </div>
      )}
      <dialog
        ref={dialog}
        className="control-dialog containment-dialog"
        onCancel={(e) => {
          if (busy) e.preventDefault();
          else setOpen(false);
        }}
        onClose={() => setOpen(false)}
      >
        <div className="row-title">
          <div>
            <div className="eyebrow">REVIEW COOPERATIVE CONTROL</div>
            <h2>Contain a dependency branch</h2>
          </div>
          <button
            className="button small"
            aria-label="Close containment review"
            disabled={busy}
            onClick={() => setOpen(false)}
          >
            Close
          </button>
        </div>
        <p className="dialog-description">
          This requests holds at currently owned, reversible checkpoints. It
          does not grant approval, retry payments, stop arbitrary code, or hold
          tasks outside the reviewed scope.
        </p>
        <label className="research-field">
          Pending approval
          <select
            aria-label="Containment approval"
            value={approval}
            onChange={(e) => {
              setApproval(e.target.value);
              setPreview(null);
            }}
          >
            {eligible.map((a) => (
              <option key={a.approval_id} value={a.approval_id}>
                {label(a.related_task_id || "")} · {short(a.approval_id)}
              </option>
            ))}
          </select>
        </label>
        <label htmlFor="containment-reason">
          Reason · recorded in control history
        </label>
        <textarea
          id="containment-reason"
          required
          maxLength={1000}
          value={reason}
          disabled={busy}
          onChange={(e) => {
            setReason(e.target.value);
            setPreview(null);
          }}
          placeholder="Explain why the shared dependency branch should wait…"
        />
        <button
          className="button secondary"
          onClick={() => void review()}
          disabled={busy || !live || !reason.trim()}
        >
          {busy ? "Checking…" : "Preview targets"}
        </button>
        {error && (
          <div className="banner warning" role="status">
            {error}
          </div>
        )}
        {preview && (
          <div className="containment-preview">
            <h3>Reviewed scope</h3>
            <p className="metadata">
              Root: {label(preview.root_task_id)} · {preview.targets.length}{" "}
              eligible of {preview.dependent_task_ids.length} declared tasks ·
              bound {preview.max_targets}
            </p>
            <div className="table-scroll">
              <table className="payment-table">
                <thead>
                  <tr>
                    <th>Task</th>
                    <th>Checkpoint / epoch</th>
                    <th>Request</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.targets.map((t) => (
                    <tr key={t.task_id}>
                      <td>{label(t.task_id)}</td>
                      <td className="mono">
                        {short(t.checkpoint_id)} · {t.fencing_epoch}
                      </td>
                      <td>Hold · task v{t.expected_task_version}</td>
                    </tr>
                  ))}
                  {preview.skipped.map((t) => (
                    <tr key={t.task_id}>
                      <td>{label(t.task_id)}</td>
                      <td colSpan={2}>
                        Skipped: {t.reason.replaceAll("_", " ")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <details>
              <summary>
                Outside the declared branch · {independent.length}
              </summary>
              <ul>
                {independent.map((n) => (
                  <li key={n.id}>{n.label}</li>
                ))}
              </ul>
            </details>
            <p className="metadata muted">
              The backend revalidates this exact preview, including task
              versions, checkpoint identities and runtime epochs. A changed
              scope requires another review.
            </p>
          </div>
        )}
        <div className="dialog-actions">
          <button
            className="button secondary"
            disabled={busy}
            onClick={() => setOpen(false)}
          >
            Cancel
          </button>
          <button
            className="button primary"
            onClick={() => void apply()}
            disabled={busy || !live || !preview?.targets.length || uncertain}
          >
            Request {preview?.targets.length || 0} holds
          </button>
        </div>
      </dialog>
    </section>
  );
}
