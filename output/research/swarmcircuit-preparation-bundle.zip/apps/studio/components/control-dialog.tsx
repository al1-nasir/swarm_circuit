"use client";
import {
  ArrowRight,
  CircleHelp,
  GitBranch,
  Pause,
  Play,
  ShieldCheck,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { closure, short } from "@/lib/model";
import type { GraphNode, Snapshot } from "@/lib/types";

export interface Draft {
  node: GraphNode;
  kind: "hold_task" | "resume_task";
}
export function ControlDialog({
  draft,
  data,
  onClose,
  onSubmit,
  blocked,
}: {
  draft: Draft;
  data: Snapshot;
  onClose: () => void;
  onSubmit: (reason: string) => Promise<void>;
  blocked: string;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [reason, setReason] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const hold = draft.kind === "hold_task";
  const affected = closure(data.taskGraph, draft.node.id);
  const current = data.taskGraph.nodes.find((n) => n.id === draft.node.id);
  const changed =
    current?.state_version !== draft.node.state_version ||
    current?.control?.checkpoint_id !== draft.node.control?.checkpoint_id ||
    current?.control?.fencing_epoch !== draft.node.control?.fencing_epoch;
  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    dialog.current?.showModal();
    return () => {
      dialog.current?.close();
      opener?.focus();
    };
  }, []);
  return (
    <dialog
      ref={dialog}
      className="control-dialog"
      aria-labelledby="control-title"
      onCancel={(e) => {
        e.preventDefault();
        if (!submitting) onClose();
      }}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (submitting || changed || blocked || !reason.trim()) return;
          setSubmitting(true);
          try {
            await onSubmit(reason.trim());
          } finally {
            setSubmitting(false);
          }
        }}
      >
        <div className="dialog-heading">
          <span className="dialog-icon">
            {hold ? <Pause size={23} /> : <Play size={23} />}
          </span>
          <button
            type="button"
            className="icon-button"
            aria-label="Cancel control request"
            disabled={submitting}
            onClick={onClose}
          >
            <X size={18} />
          </button>
        </div>
        <div className="eyebrow">REVIEW COOPERATIVE CONTROL</div>
        <h2 id="control-title">{hold ? "Request hold" : "Request resume"}</h2>
        <p className="dialog-description">{draft.node.label}</p>
        <div className="dialog-target">
          <GitBranch size={18} />
          <div>
            <strong>
              {short(draft.node.id)}
              <span className="muted"> · task v{draft.node.state_version}</span>
            </strong>
            <small>
              Checkpoint{" "}
              {draft.node.control?.checkpoint_id
                ? short(draft.node.control.checkpoint_id)
                : "unavailable"}{" "}
              · epoch {draft.node.control?.fencing_epoch}
            </small>
          </div>
          <span className="mode control">Control</span>
        </div>
        <div className="dialog-impact">
          <h3>What this request affects</h3>
          <p>
            {hold
              ? "This task parks only after its active runtime acknowledges the owned reversible checkpoint."
              : "The runtime must validate prerequisites and acknowledge this specific resume before work continues."}
          </p>
          <div>
            <span>
              <strong>1</strong>target task
            </span>
            <span>
              <strong>{Math.max(0, affected.size - 1)}</strong>downstream
              context
            </span>
            <span>
              <strong>{data.taskGraph.nodes.length - affected.size}</strong>
              outside this branch
            </span>
          </div>
        </div>
        <div className="banner info">
          <ShieldCheck size={17} />
          <span>
            This does not interrupt in-flight work, approve a payment, or
            override a safety decision. Downstream tasks are not individually
            held by this request.
          </span>
        </div>
        <label className="reason-label" htmlFor="control-reason">
          Reason <span>Required · recorded in command history</span>
        </label>
        <textarea
          id="control-reason"
          autoFocus
          maxLength={1000}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder={
            hold
              ? "Explain why this task should wait…"
              : "Explain why prerequisites now permit resumption…"
          }
          required
          disabled={submitting}
        />
        {(changed || blocked) && (
          <div role="status" className="banner warning">
            {changed
              ? "Task or runtime changed since review. Cancel and open a fresh review."
              : blocked}
          </div>
        )}
        <div className="dialog-footer">
          <button
            type="button"
            className="button secondary"
            onClick={onClose}
            disabled={submitting}
          >
            Cancel
          </button>
          <button
            className="button primary"
            disabled={
              submitting || changed || Boolean(blocked) || !reason.trim()
            }
          >
            {submitting
              ? "Submitting…"
              : hold
                ? "Request hold"
                : "Request resume"}
            <ArrowRight size={15} />
          </button>
        </div>
        <p className="dialog-footnote">
          <CircleHelp size={12} />A queued request is not an applied
          intervention.
        </p>
      </form>
    </dialog>
  );
}
