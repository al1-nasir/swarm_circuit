# SwarmCircuit Studio

Local Next.js App Router, TypeScript, Tailwind and React Flow frontend for the
Phase 1–6 backend. Requires Node 22.18+; verified with Node 22.23.4 and npm.

From the repository root:

```bash
make bootstrap
make init-local
make server
# In another terminal:
make studio-install
make studio
# http://127.0.0.1:3000
```

`make demo` creates an explicitly simulated Observe workflow. `make demo-studio`
opens a reversible checkpoint for up to 240 seconds: select its protected task,
review a hold with a reason, wait for the matching runtime ACK, then review resume.
The independent task completes while held and one mock action executes on resume.
No payment or approval authority is exercised by this example.

For alternate ports, use `make server PORT=18005` and
`SWARM_API_URL=http://127.0.0.1:18005 make studio STUDIO_PORT=3300`.
The Node custom server binds to loopback, reads root `.env` on the server only and
requires the configured project/SDK token. `SWARM_OPERATOR_TOKEN` enables reviewed
hold/resume. `SWARM_STUDIO_READ_ONLY=true` disables those writes regardless of the
token. No `NEXT_PUBLIC_*` credential is used. Restart the Node server after changing
environment settings. This trusts other users of the local machine; it does not
provide multi-user sessions or a remotely deployable authentication boundary.

```bash
make studio-check
# Production preview after a successful build:
npm --prefix apps/studio start
# Opt-in real protocol tests with both services running:
cd apps/studio
STUDIO_URL=http://127.0.0.1:3000 npm run test:integration
```

`check` runs Prettier, strict TypeScript, twelve meaningful Node unit tests and
`next build --webpack`. Integration tests use HTTP/WebSocket protocols and create
one labelled simulation run. They test credential isolation, origin/route guards,
read-only streaming and reconnect replay. Browser verification is recorded in the
[delivery report](../../docs/PHASE5_DELIVERY.md); it is separate from these tests.

The allowlisted same-origin gateway exposes project-scoped reads and only the
validated single-task and preview-bound group containment routes. `/studio-ws/{run_id}` relays a
read-only backend stream; short-lived backend tickets stay server-side. Canonical
REST snapshots determine state. Queued/dispatched commands are pending requests;
only a matching session/epoch ACK establishes applied. Uncertain submission keeps
the original idempotency key and reconciles history without automatic resubmission.
Browser storage contains reconciliation intent IDs and recently opened workflow IDs/names, never tokens or reasons.

Workflows support loaded-page search/filters and explicit pagination. The graph
has a click-based list alternative and caps its canvas at 200 nodes/400 edges; the
list retains all loaded nodes. Timeline DOM rows are virtualized. Older pages load
on request, and loaded mutable payment/approval/command windows refresh. Small
screens default to the task list and hide the inspector until selected.

Graph layout runs in a dedicated ELK worker, with rounded orthogonal routes. Custom search shortcuts, timeline key handlers and graph keyboard actions have been removed; ordinary native focus and button/link behavior remain.

Payments and approval decisions remain read-only. The Approvals tab also offers
reviewed dependency containment: preview eligible/skipped tasks, supply a reason,
confirm the exact preview hash, then reconcile canonical runtime ACKs. Evidence labels distinguish SDK
observations, self-reported traces, derived findings and simulation authority.
Experiments compare stored synthetic/LLM workload-replay trials with scenario and
metric filters, matched-seed intervals, raw truth/observation downloads and CSV.
Paid model calls run only through the explicitly invoked local CLI. An initial
uncached bootstrap result can take up to two minutes; subsequent reads are cached.
The custom server is required for the socket relay; `next start`, static export and
standalone deployment are not supported. See the
[architecture decision](../../docs/decisions/0005-studio.md) for the protocol and limits.

See [the dashboard refinement report](../../docs/STUDIO_REFINEMENT.md) for the two-tone design, asset sources and reliability checks.
