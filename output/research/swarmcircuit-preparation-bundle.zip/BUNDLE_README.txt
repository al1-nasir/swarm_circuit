SwarmCircuit preparation reproducibility bundle - November 5, 2026

This is pre-sprint preparation, not an event-period submission or release.
The repository has no selected open-source license; this local archive does not
confer redistribution rights to supplied documents or third-party dependencies.
No .env, private database, credential, dependency installation or build cache is
included. Screenshots show mock workflows. Author/affiliation metadata needs review.

1. Extract; install Python 3.11+, uv and Node 22.18+.
2. make bootstrap; make init-local; make db-init; make server PORT=18005.
3. Offline replay (no provider calls):
   make research-verify EXPERIMENT_DIR=artifacts/research/0ada95ca-a10a-4835-ade4-31c088c2e031
   Repeat for each failed-study directory; expected verified completed trials 0.
4. make research recreates the synthetic study under a NEW UUID and populates the
   local DB; the included raw files do not ship a private SQLite database.
5. make studio-install; SWARM_API_URL=http://127.0.0.1:18005 make studio STUDIO_PORT=3300.
6. SWARM_API_URL=http://127.0.0.1:18005 make demo-containment for fresh SDK boundaries.
7. Optional paid calls require private provider configuration and an explicit
   make research-llm invocation. The included pilots FAILED. Do not treat them as
   completed live-model evidence. No call is needed to verify the archive.

The PDF is output/pdf/swarmcircuit-research-draft.pdf. Source script:
scripts/build_research_report.py (ReportLab 4.5.1, Matplotlib 3.11.2; Linux
Liberation Sans TrueType fonts). It reads the included results, not the network.
See experiments/README.md for metrics, censoring, denominators and limitations;
docs/DEMO_SCRIPT.md for the four-minute walkthrough; docs/PHASE6_DELIVERY.md
for actual checks. Model replay is open-loop; zero unsafe starts is a common
simulator guard invariant, not measured real-world risk. The queue outperforms
backpressure on some workloads. Graph/telemetry counterexamples are retained.

BUNDLE_MANIFEST.json maps each included member to its SHA-256. Validate those
hashes after extraction. The manifest itself and this README are container
metadata. Research manifests separately seal protocol, original source files,
CSV and completed trial journals. No Git commit is invented.
